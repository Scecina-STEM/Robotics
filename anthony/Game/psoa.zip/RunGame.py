from SaveData import *

def SetupGame(map_name:str) -> None:
    print("lol")
    map_data = MapData(map_name)
    print(map_data)

def StartGame(map_name) -> None:
    print("Lol")
    map_data = MapData()