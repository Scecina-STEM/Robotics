# Game State
GamePath:str
Level:int
CharacterName:str
# Game Data
Health:int
ArmourClass:int
Inventory:list
Requirements:list